SMART LIBRARY ASSISTANT - ANDROID PROJECT

This is an Android Studio project source, not a prebuilt APK.

HOW TO BUILD THE APK:
1. Install Android Studio on a computer.
2. Extract this ZIP file.
3. In Android Studio choose Open, then select the extracted Smart_Library_Assistant_Android folder.
4. Allow Android Studio to download the Gradle and Android dependencies.
5. Connect an Android phone or use an emulator to test.
6. Choose Build > Build Bundle(s) / APK(s) > Build APK(s).
7. Android Studio will show the APK location when the build completes.

FEATURES:
- Student profile: name, class, age, hobbies and reading level
- Interest/age/level based book recommendations
- Reading history saved locally on the device
- Five sample book records
- QR code generation for each sample book
- Camera QR scanning and book information display
- Book rack and availability information

IMPORTANT:
- Internet is currently needed to load the QR generator and scanner JavaScript libraries.
- Camera permission is needed for QR scanning.
- The five books are demonstration records. Replace them with real school library records.
- Recommendation logic is rule-based, not a machine-learning model.
- Student profile and reading history are stored locally on this device using browser storage.
